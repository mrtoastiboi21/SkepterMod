
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.skeptersalpha.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.common.ForgeSpawnEggItem;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.BlockItem;

import net.mcreator.skeptersalpha.item.SkepterItem;
import net.mcreator.skeptersalpha.item.SkeptSwordItem;
import net.mcreator.skeptersalpha.item.SkeptShovelItem;
import net.mcreator.skeptersalpha.item.SkeptPickaxeItem;
import net.mcreator.skeptersalpha.item.SkeptIngotItem;
import net.mcreator.skeptersalpha.item.SkeptHoeItem;
import net.mcreator.skeptersalpha.item.SkeptAxeItem;
import net.mcreator.skeptersalpha.item.SeptusgArmorItem;
import net.mcreator.skeptersalpha.item.SeptusItem;
import net.mcreator.skeptersalpha.SkeptersAlphaMod;

public class SkeptersAlphaModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, SkeptersAlphaMod.MODID);
	public static final RegistryObject<Item> SKEPTER = REGISTRY.register("skepter", () -> new SkepterItem());
	public static final RegistryObject<Item> SKATTLE_SPAWN_EGG = REGISTRY.register("skattle_spawn_egg", () -> new ForgeSpawnEggItem(SkeptersAlphaModEntities.SKATTLE, -16724941, -52327, new Item.Properties().tab(CreativeModeTab.TAB_MISC)));
	public static final RegistryObject<Item> SEPTUS_BLOCK = block(SkeptersAlphaModBlocks.SEPTUS_BLOCK, CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final RegistryObject<Item> SEPTUS_ORE = block(SkeptersAlphaModBlocks.SEPTUS_ORE, CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final RegistryObject<Item> SKEPT_ORE = block(SkeptersAlphaModBlocks.SKEPT_ORE, CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final RegistryObject<Item> SKEPT_BLOCK = block(SkeptersAlphaModBlocks.SKEPT_BLOCK, CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final RegistryObject<Item> SKEPT_INGOT = REGISTRY.register("skept_ingot", () -> new SkeptIngotItem());
	public static final RegistryObject<Item> SEPTUS = REGISTRY.register("septus", () -> new SeptusItem());
	public static final RegistryObject<Item> SEPTUSG_ARMOR_HELMET = REGISTRY.register("septusg_armor_helmet", () -> new SeptusgArmorItem.Helmet());
	public static final RegistryObject<Item> SEPTUSG_ARMOR_CHESTPLATE = REGISTRY.register("septusg_armor_chestplate", () -> new SeptusgArmorItem.Chestplate());
	public static final RegistryObject<Item> SEPTUSG_ARMOR_LEGGINGS = REGISTRY.register("septusg_armor_leggings", () -> new SeptusgArmorItem.Leggings());
	public static final RegistryObject<Item> SEPTUSG_ARMOR_BOOTS = REGISTRY.register("septusg_armor_boots", () -> new SeptusgArmorItem.Boots());
	public static final RegistryObject<Item> SKEPT_PICKAXE = REGISTRY.register("skept_pickaxe", () -> new SkeptPickaxeItem());
	public static final RegistryObject<Item> SKEPT_AXE = REGISTRY.register("skept_axe", () -> new SkeptAxeItem());
	public static final RegistryObject<Item> SKEPT_SWORD = REGISTRY.register("skept_sword", () -> new SkeptSwordItem());
	public static final RegistryObject<Item> SKEPT_SHOVEL = REGISTRY.register("skept_shovel", () -> new SkeptShovelItem());
	public static final RegistryObject<Item> SKEPT_HOE = REGISTRY.register("skept_hoe", () -> new SkeptHoeItem());

	private static RegistryObject<Item> block(RegistryObject<Block> block, CreativeModeTab tab) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties().tab(tab)));
	}
}

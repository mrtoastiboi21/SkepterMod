
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.skeptersalpha.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import net.mcreator.skeptersalpha.block.SkeptOreBlock;
import net.mcreator.skeptersalpha.block.SkeptBlockBlock;
import net.mcreator.skeptersalpha.block.SeptusOreBlock;
import net.mcreator.skeptersalpha.block.SeptusBlockBlock;
import net.mcreator.skeptersalpha.SkeptersAlphaMod;

public class SkeptersAlphaModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, SkeptersAlphaMod.MODID);
	public static final RegistryObject<Block> SEPTUS_BLOCK = REGISTRY.register("septus_block", () -> new SeptusBlockBlock());
	public static final RegistryObject<Block> SEPTUS_ORE = REGISTRY.register("septus_ore", () -> new SeptusOreBlock());
	public static final RegistryObject<Block> SKEPT_ORE = REGISTRY.register("skept_ore", () -> new SkeptOreBlock());
	public static final RegistryObject<Block> SKEPT_BLOCK = REGISTRY.register("skept_block", () -> new SkeptBlockBlock());
}

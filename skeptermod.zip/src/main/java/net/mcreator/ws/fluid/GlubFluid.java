
package net.mcreator.ws.fluid;

import net.neoforged.neoforge.fluids.BaseFlowingFluid;

import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.LiquidBlock;

import net.mcreator.ws.init.TheskeptermodModItems;
import net.mcreator.ws.init.TheskeptermodModFluids;
import net.mcreator.ws.init.TheskeptermodModFluidTypes;
import net.mcreator.ws.init.TheskeptermodModBlocks;

public abstract class GlubFluid extends BaseFlowingFluid {
	public static final BaseFlowingFluid.Properties PROPERTIES = new BaseFlowingFluid.Properties(() -> TheskeptermodModFluidTypes.GLUB_TYPE.get(), () -> TheskeptermodModFluids.GLUB.get(), () -> TheskeptermodModFluids.FLOWING_GLUB.get())
			.explosionResistance(100f).bucket(() -> TheskeptermodModItems.GLUB_BUCKET.get()).block(() -> (LiquidBlock) TheskeptermodModBlocks.GLUB.get());

	private GlubFluid() {
		super(PROPERTIES);
	}

	public static class Source extends GlubFluid {
		public int getAmount(FluidState state) {
			return 8;
		}

		public boolean isSource(FluidState state) {
			return true;
		}
	}

	public static class Flowing extends GlubFluid {
		protected void createFluidStateDefinition(StateDefinition.Builder<Fluid, FluidState> builder) {
			super.createFluidStateDefinition(builder);
			builder.add(LEVEL);
		}

		public int getAmount(FluidState state) {
			return state.getValue(LEVEL);
		}

		public boolean isSource(FluidState state) {
			return false;
		}
	}
}

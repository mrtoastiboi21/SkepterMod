
package net.mcreator.ws.fluid;

import net.neoforged.neoforge.fluids.BaseFlowingFluid;

import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.LiquidBlock;

import net.mcreator.ws.init.TheskeptermodModItems;
import net.mcreator.ws.init.TheskeptermodModFluids;
import net.mcreator.ws.init.TheskeptermodModFluidTypes;
import net.mcreator.ws.init.TheskeptermodModBlocks;

public abstract class WasterFluid extends BaseFlowingFluid {
	public static final BaseFlowingFluid.Properties PROPERTIES = new BaseFlowingFluid.Properties(() -> TheskeptermodModFluidTypes.WASTER_TYPE.get(), () -> TheskeptermodModFluids.WASTER.get(), () -> TheskeptermodModFluids.FLOWING_WASTER.get())
			.explosionResistance(100f).bucket(() -> TheskeptermodModItems.WASTER_BUCKET.get()).block(() -> (LiquidBlock) TheskeptermodModBlocks.WASTER.get());

	private WasterFluid() {
		super(PROPERTIES);
	}

	public static class Source extends WasterFluid {
		public int getAmount(FluidState state) {
			return 8;
		}

		public boolean isSource(FluidState state) {
			return true;
		}
	}

	public static class Flowing extends WasterFluid {
		protected void createFluidStateDefinition(StateDefinition.Builder<Fluid, FluidState> builder) {
			super.createFluidStateDefinition(builder);
			builder.add(LEVEL);
		}

		public int getAmount(FluidState state) {
			return state.getValue(LEVEL);
		}

		public boolean isSource(FluidState state) {
			return false;
		}
	}
}

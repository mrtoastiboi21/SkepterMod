
package net.mcreator.ws.fluid;

import net.neoforged.neoforge.fluids.BaseFlowingFluid;

import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.particles.ParticleOptions;

import net.mcreator.ws.init.TheskeptermodModItems;
import net.mcreator.ws.init.TheskeptermodModFluids;
import net.mcreator.ws.init.TheskeptermodModFluidTypes;
import net.mcreator.ws.init.TheskeptermodModBlocks;

public abstract class BludgeFluid extends BaseFlowingFluid {
	public static final BaseFlowingFluid.Properties PROPERTIES = new BaseFlowingFluid.Properties(() -> TheskeptermodModFluidTypes.BLUDGE_TYPE.get(), () -> TheskeptermodModFluids.BLUDGE.get(), () -> TheskeptermodModFluids.FLOWING_BLUDGE.get())
			.explosionResistance(100f).bucket(() -> TheskeptermodModItems.BLUDGE_BUCKET.get()).block(() -> (LiquidBlock) TheskeptermodModBlocks.BLUDGE.get());

	private BludgeFluid() {
		super(PROPERTIES);
	}

	@Override
	public ParticleOptions getDripParticle() {
		return ParticleTypes.SPIT;
	}

	public static class Source extends BludgeFluid {
		public int getAmount(FluidState state) {
			return 8;
		}

		public boolean isSource(FluidState state) {
			return true;
		}
	}

	public static class Flowing extends BludgeFluid {
		protected void createFluidStateDefinition(StateDefinition.Builder<Fluid, FluidState> builder) {
			super.createFluidStateDefinition(builder);
			builder.add(LEVEL);
		}

		public int getAmount(FluidState state) {
			return state.getValue(LEVEL);
		}

		public boolean isSource(FluidState state) {
			return false;
		}
	}
}

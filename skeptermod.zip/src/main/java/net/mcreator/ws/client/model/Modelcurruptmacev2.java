package net.mcreator.ws.client.model;

import net.minecraft.world.entity.Entity;
import net.minecraft.util.Mth;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.EntityModel;

import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.blaze3d.vertex.PoseStack;

// Made with Blockbench 4.11.1
// Exported for Minecraft version 1.17 or later with Mojang mappings
// Paste this class into your mod and generate all required imports
public class Modelcurruptmacev2<T extends Entity> extends EntityModel<T> {
	// This layer location should be baked with EntityRendererProvider.Context in
	// the entity renderer and passed into this model's constructor
	public static final ModelLayerLocation LAYER_LOCATION = new ModelLayerLocation(ResourceLocation.fromNamespaceAndPath("theskeptermod", "modelcurruptmacev_2"), "main");
	public final ModelPart face2;
	public final ModelPart face1;
	public final ModelPart body;
	public final ModelPart arm;
	public final ModelPart arm2;
	public final ModelPart leg;
	public final ModelPart leg2;

	public Modelcurruptmacev2(ModelPart root) {
		this.face2 = root.getChild("face2");
		this.face1 = root.getChild("face1");
		this.body = root.getChild("body");
		this.arm = root.getChild("arm");
		this.arm2 = root.getChild("arm2");
		this.leg = root.getChild("leg");
		this.leg2 = root.getChild("leg2");
	}

	public static LayerDefinition createBodyLayer() {
		MeshDefinition meshdefinition = new MeshDefinition();
		PartDefinition partdefinition = meshdefinition.getRoot();
		PartDefinition face2 = partdefinition.addOrReplaceChild("face2", CubeListBuilder.create(), PartPose.offset(0.0F, -7.0F, -2.0F));
		PartDefinition cube_r1 = face2.addOrReplaceChild("cube_r1", CubeListBuilder.create().texOffs(0, 14).addBox(-4.0F, -6.0F, -6.0F, 4.0F, 8.0F, 7.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, -10.0F, 1.0F, 0.0F, 0.2618F, 0.0F));
		PartDefinition cube_r2 = face2.addOrReplaceChild("cube_r2", CubeListBuilder.create().texOffs(48, 29).addBox(-2.0F, -2.0F, -1.0F, 2.0F, 2.0F, 2.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-3.0F, -18.0F, 0.0F, 0.0F, 0.0F, -0.0436F));
		PartDefinition cube_r3 = face2.addOrReplaceChild("cube_r3", CubeListBuilder.create().texOffs(40, 29).addBox(-2.0F, -4.0F, -1.0F, 2.0F, 4.0F, 2.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-4.0F, -14.0F, 0.0F, 0.0F, 0.0F, -0.0436F));
		PartDefinition face1 = partdefinition.addOrReplaceChild("face1", CubeListBuilder.create(), PartPose.offset(0.0F, -7.0F, -2.0F));
		PartDefinition cube_r4 = face1.addOrReplaceChild("cube_r4", CubeListBuilder.create().texOffs(22, 14).addBox(0.0F, -6.0F, -6.0F, 4.0F, 8.0F, 7.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, -10.0F, 1.0F, 0.0F, -0.2618F, 0.0F));
		PartDefinition cube_r5 = face1.addOrReplaceChild("cube_r5", CubeListBuilder.create().texOffs(40, 35).addBox(-2.0F, -4.0F, -1.0F, 2.0F, 4.0F, 2.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(6.0F, -14.0F, 0.0F, 0.0F, 0.0F, 0.0873F));
		PartDefinition body = partdefinition.addOrReplaceChild("body",
				CubeListBuilder.create().texOffs(24, 0).addBox(-4.0F, -10.0F, -2.0F, 8.0F, 4.0F, 4.0F, new CubeDeformation(0.0F)).texOffs(40, 47).addBox(2.0F, -19.0F, -3.0F, 3.0F, 1.0F, 2.0F, new CubeDeformation(0.0F)).texOffs(48, 3)
						.addBox(2.0F, -16.0F, -3.0F, 3.0F, 1.0F, 2.0F, new CubeDeformation(0.0F)).texOffs(48, 6).addBox(-5.0F, -16.0F, -3.0F, 3.0F, 1.0F, 2.0F, new CubeDeformation(0.0F)).texOffs(48, 9)
						.addBox(-5.0F, -13.0F, -3.0F, 3.0F, 1.0F, 2.0F, new CubeDeformation(0.0F)).texOffs(24, 48).addBox(2.0F, -13.0F, -3.0F, 3.0F, 1.0F, 2.0F, new CubeDeformation(0.0F)).texOffs(48, 0)
						.addBox(-5.0F, -19.0F, -3.0F, 3.0F, 1.0F, 2.0F, new CubeDeformation(0.0F)).texOffs(48, 33).addBox(-1.0F, -16.0F, -3.0F, 2.0F, 2.0F, 2.0F, new CubeDeformation(0.0F)),
				PartPose.offset(0.0F, 5.0F, 0.0F));
		PartDefinition cube_r6 = body.addOrReplaceChild("cube_r6", CubeListBuilder.create().texOffs(0, 0).addBox(-4.0F, -10.0F, -2.0F, 8.0F, 10.0F, 4.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, -10.0F, 0.0F, 0.0873F, 0.0F, 0.0F));
		PartDefinition arm = partdefinition.addOrReplaceChild("arm",
				CubeListBuilder.create().texOffs(34, 48).addBox(-1.0F, 15.0F, -1.0F, 2.0F, 2.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(48, 40).addBox(-1.0F, 17.0F, 0.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(0, 29)
						.addBox(-1.0F, -8.0F, -1.0F, 2.0F, 23.0F, 2.0F, new CubeDeformation(0.0F)).texOffs(16, 29).addBox(-1.0F, -8.0F, -1.0F, 2.0F, 23.0F, 2.0F, new CubeDeformation(0.0F)),
				PartPose.offset(-5.0F, -6.0F, -1.0F));
		PartDefinition arm2 = partdefinition.addOrReplaceChild("arm2", CubeListBuilder.create().texOffs(48, 37).addBox(-1.0F, 15.0F, -1.0F, 2.0F, 2.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(48, 42)
				.addBox(-1.0F, 17.0F, 0.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(8, 29).addBox(-1.0F, -8.0F, -1.0F, 2.0F, 23.0F, 2.0F, new CubeDeformation(0.0F)), PartPose.offset(5.0F, -6.0F, -1.0F));
		PartDefinition leg = partdefinition.addOrReplaceChild("leg",
				CubeListBuilder.create().texOffs(44, 24).addBox(-1.0F, 2.0F, 0.0F, 2.0F, 3.0F, 2.0F, new CubeDeformation(0.0F)).texOffs(24, 29).addBox(-1.0F, 5.0F, -1.0F, 2.0F, 17.0F, 2.0F, new CubeDeformation(0.0F)).texOffs(40, 41)
						.addBox(-1.0F, 22.0F, 0.0F, 2.0F, 4.0F, 2.0F, new CubeDeformation(0.0F)).texOffs(24, 8).addBox(-1.0F, 26.0F, -1.0F, 2.0F, 1.0F, 4.0F, new CubeDeformation(0.0F)),
				PartPose.offset(2.0F, -3.0F, -1.0F));
		PartDefinition leg2 = partdefinition.addOrReplaceChild("leg2",
				CubeListBuilder.create().texOffs(32, 29).addBox(-1.0F, 5.0F, -1.0F, 2.0F, 17.0F, 2.0F, new CubeDeformation(0.0F)).texOffs(44, 19).addBox(-1.0F, 2.0F, 0.0F, 2.0F, 3.0F, 2.0F, new CubeDeformation(0.0F)).texOffs(44, 13)
						.addBox(-1.0F, 22.0F, 0.0F, 2.0F, 4.0F, 2.0F, new CubeDeformation(0.0F)).texOffs(36, 8).addBox(-1.0F, 26.0F, -1.0F, 2.0F, 1.0F, 4.0F, new CubeDeformation(0.0F)),
				PartPose.offset(-2.0F, -3.0F, -1.0F));
		return LayerDefinition.create(meshdefinition, 64, 64);
	}

	@Override
	public void renderToBuffer(PoseStack poseStack, VertexConsumer vertexConsumer, int packedLight, int packedOverlay, int rgb) {
		face2.render(poseStack, vertexConsumer, packedLight, packedOverlay, rgb);
		face1.render(poseStack, vertexConsumer, packedLight, packedOverlay, rgb);
		body.render(poseStack, vertexConsumer, packedLight, packedOverlay, rgb);
		arm.render(poseStack, vertexConsumer, packedLight, packedOverlay, rgb);
		arm2.render(poseStack, vertexConsumer, packedLight, packedOverlay, rgb);
		leg.render(poseStack, vertexConsumer, packedLight, packedOverlay, rgb);
		leg2.render(poseStack, vertexConsumer, packedLight, packedOverlay, rgb);
	}

	public void setupAnim(T entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
		this.leg2.xRot = Mth.cos(limbSwing * 1.0F) * -1.0F * limbSwingAmount;
		this.face1.yRot = netHeadYaw / (180F / (float) Math.PI);
		this.face1.xRot = headPitch / (180F / (float) Math.PI);
		this.face2.yRot = netHeadYaw / (180F / (float) Math.PI);
		this.face2.xRot = headPitch / (180F / (float) Math.PI);
		this.leg.xRot = Mth.cos(limbSwing * 1.0F) * 1.0F * limbSwingAmount;
	}
}

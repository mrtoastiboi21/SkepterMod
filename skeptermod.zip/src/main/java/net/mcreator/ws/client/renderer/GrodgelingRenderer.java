
package net.mcreator.ws.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;

import net.mcreator.ws.entity.GrodgelingEntity;
import net.mcreator.ws.client.model.Modelsqueemling;

public class GrodgelingRenderer extends MobRenderer<GrodgelingEntity, Modelsqueemling<GrodgelingEntity>> {
	public GrodgelingRenderer(EntityRendererProvider.Context context) {
		super(context, new Modelsqueemling(context.bakeLayer(Modelsqueemling.LAYER_LOCATION)), 0.5f);
	}

	@Override
	public ResourceLocation getTextureLocation(GrodgelingEntity entity) {
		return ResourceLocation.parse("theskeptermod:textures/entities/groing.png");
	}
}

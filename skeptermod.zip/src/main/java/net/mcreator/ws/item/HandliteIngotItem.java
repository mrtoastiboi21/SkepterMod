
package net.mcreator.ws.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class HandliteIngotItem extends Item {
	public HandliteIngotItem() {
		super(new Item.Properties().stacksTo(64).rarity(Rarity.COMMON));
	}
}

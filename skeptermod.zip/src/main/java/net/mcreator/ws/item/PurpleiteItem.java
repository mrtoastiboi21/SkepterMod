
package net.mcreator.ws.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class PurpleiteItem extends Item {
	public PurpleiteItem() {
		super(new Item.Properties().stacksTo(64).rarity(Rarity.COMMON));
	}
}

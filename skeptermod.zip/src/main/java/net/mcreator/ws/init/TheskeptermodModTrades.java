
/*
*	MCreator note: This file will be REGENERATED on each build.
*/
package net.mcreator.ws.init;

import net.neoforged.neoforge.event.village.VillagerTradesEvent;
import net.neoforged.neoforge.common.BasicItemListing;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;

@EventBusSubscriber
public class TheskeptermodModTrades {
	@SubscribeEvent
	public static void registerTrades(VillagerTradesEvent event) {
		if (event.getType() == TheskeptermodModVillagerProfessions.SKEPTIC_TRADE.get()) {
			event.getTrades().get(1)
					.add(new BasicItemListing(new ItemStack(TheskeptermodModItems.SKEPTER_SHARD.get(), 4), new ItemStack(TheskeptermodModItems.GLUB_BUCKET.get(), 2), new ItemStack(TheskeptermodModItems.THE_USELESS_DISK.get()), 10, 5, 0.05f));
			event.getTrades().get(1).add(new BasicItemListing(new ItemStack(TheskeptermodModBlocks.PLOSIS.get(), 5), new ItemStack(TheskeptermodModItems.SKUTTLE_GEM.get(), 3), 10, 5, 0.05f));
			event.getTrades().get(2).add(new BasicItemListing(new ItemStack(TheskeptermodModItems.TISSUEBOX.get(), 2), new ItemStack(TheskeptermodModItems.USELESS_DISK_2_USELESS_BOOGALOO.get()), 10, 5, 0.05f));
			event.getTrades().get(3).add(new BasicItemListing(new ItemStack(TheskeptermodModBlocks.LUCIDPLANT.get()), new ItemStack(TheskeptermodModItems.USELESS_DISK_3_EVENMOREUSELESS.get()), 10, 5, 0.05f));
			event.getTrades().get(4)
					.add(new BasicItemListing(new ItemStack(TheskeptermodModItems.SKEPTER_HANDLE.get()), new ItemStack(TheskeptermodModItems.SKEPTER_SHARD.get()), new ItemStack(TheskeptermodModItems.BASIC_SKEPTER.get()), 10, 5, 0.05f));
			event.getTrades().get(3)
					.add(new BasicItemListing(new ItemStack(TheskeptermodModItems.GLAIN_GEM.get(), 3), new ItemStack(TheskeptermodModItems.BREAKSTONE_INGOT.get()), new ItemStack(TheskeptermodModItems.BOTTLE_OF_STANGE_LIQUID.get()), 10, 5, 0.05f));
			event.getTrades().get(2)
					.add(new BasicItemListing(new ItemStack(TheskeptermodModBlocks.BREAKSTONE_ORE.get()), new ItemStack(TheskeptermodModItems.BLUESFLESH.get(), 5), new ItemStack(TheskeptermodModItems.ENOSIS_DUST.get()), 10, 5, 0.05f));
			event.getTrades().get(4).add(new BasicItemListing(new ItemStack(TheskeptermodModItems.COOKEDLATIC.get()), new ItemStack(TheskeptermodModItems.BREAKSTONE_SWORD.get()), 10, 5, 0.05f));
			event.getTrades().get(1).add(new BasicItemListing(new ItemStack(Items.HONEY_BOTTLE), new ItemStack(TheskeptermodModItems.HAMMER.get()), 10, 5, 0.05f));
			event.getTrades().get(4)
					.add(new BasicItemListing(new ItemStack(TheskeptermodModItems.BREAKSTONE_INGOT.get(), 2), new ItemStack(TheskeptermodModItems.HANDLITE_INGOT.get()), new ItemStack(TheskeptermodModItems.THE_LUCIDSWORD.get()), 10, 5, 0.05f));
			event.getTrades().get(5)
					.add(new BasicItemListing(new ItemStack(TheskeptermodModItems.HAMBLEPEPPER.get(), 25), new ItemStack(TheskeptermodModBlocks.H_IOSIS_BLOCK.get(), 6), new ItemStack(TheskeptermodModItems.SKEPTIC_DIMENSION.get()), 10, 5, 0.05f));
			event.getTrades().get(5).add(new BasicItemListing(new ItemStack(TheskeptermodModItems.OVERPOWERDISK.get(), 2), new ItemStack(TheskeptermodModItems.GLAIN_GEM_AXE.get()), new ItemStack(TheskeptermodModItems.PURPO.get()), 10, 5, 0.05f));
		}
	}
}


/*
 * MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.ws.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.fml.event.lifecycle.FMLClientSetupEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.material.FlowingFluid;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.ItemBlockRenderTypes;

import net.mcreator.ws.fluid.WasterFluid;
import net.mcreator.ws.fluid.GlubFluid;
import net.mcreator.ws.fluid.BludgeFluid;
import net.mcreator.ws.TheskeptermodMod;

public class TheskeptermodModFluids {
	public static final DeferredRegister<Fluid> REGISTRY = DeferredRegister.create(BuiltInRegistries.FLUID, TheskeptermodMod.MODID);
	public static final DeferredHolder<Fluid, FlowingFluid> WASTER = REGISTRY.register("waster", () -> new WasterFluid.Source());
	public static final DeferredHolder<Fluid, FlowingFluid> FLOWING_WASTER = REGISTRY.register("flowing_waster", () -> new WasterFluid.Flowing());
	public static final DeferredHolder<Fluid, FlowingFluid> GLUB = REGISTRY.register("glub", () -> new GlubFluid.Source());
	public static final DeferredHolder<Fluid, FlowingFluid> FLOWING_GLUB = REGISTRY.register("flowing_glub", () -> new GlubFluid.Flowing());
	public static final DeferredHolder<Fluid, FlowingFluid> BLUDGE = REGISTRY.register("bludge", () -> new BludgeFluid.Source());
	public static final DeferredHolder<Fluid, FlowingFluid> FLOWING_BLUDGE = REGISTRY.register("flowing_bludge", () -> new BludgeFluid.Flowing());

	@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
	public static class FluidsClientSideHandler {
		@SubscribeEvent
		public static void clientSetup(FMLClientSetupEvent event) {
			ItemBlockRenderTypes.setRenderLayer(WASTER.get(), RenderType.translucent());
			ItemBlockRenderTypes.setRenderLayer(FLOWING_WASTER.get(), RenderType.translucent());
			ItemBlockRenderTypes.setRenderLayer(GLUB.get(), RenderType.translucent());
			ItemBlockRenderTypes.setRenderLayer(FLOWING_GLUB.get(), RenderType.translucent());
			ItemBlockRenderTypes.setRenderLayer(BLUDGE.get(), RenderType.translucent());
			ItemBlockRenderTypes.setRenderLayer(FLOWING_BLUDGE.get(), RenderType.translucent());
		}
	}
}

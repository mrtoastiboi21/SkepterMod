
/*
 * MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.ws.init;

import net.neoforged.neoforge.registries.NeoForgeRegistries;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.fluids.FluidType;

import net.mcreator.ws.fluid.types.WasterFluidType;
import net.mcreator.ws.fluid.types.GlubFluidType;
import net.mcreator.ws.fluid.types.BludgeFluidType;
import net.mcreator.ws.TheskeptermodMod;

public class TheskeptermodModFluidTypes {
	public static final DeferredRegister<FluidType> REGISTRY = DeferredRegister.create(NeoForgeRegistries.FLUID_TYPES, TheskeptermodMod.MODID);
	public static final DeferredHolder<FluidType, FluidType> WASTER_TYPE = REGISTRY.register("waster", () -> new WasterFluidType());
	public static final DeferredHolder<FluidType, FluidType> GLUB_TYPE = REGISTRY.register("glub", () -> new GlubFluidType());
	public static final DeferredHolder<FluidType, FluidType> BLUDGE_TYPE = REGISTRY.register("bludge", () -> new BludgeFluidType());
}

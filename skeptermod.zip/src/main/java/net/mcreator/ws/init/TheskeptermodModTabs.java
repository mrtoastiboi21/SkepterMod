
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.ws.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;

import net.mcreator.ws.TheskeptermodMod;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD)
public class TheskeptermodModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, TheskeptermodMod.MODID);
	public static final DeferredHolder<CreativeModeTab, CreativeModeTab> NEWSTUFF = REGISTRY.register("newstuff",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.theskeptermod.newstuff")).icon(() -> new ItemStack(TheskeptermodModItems.EMPTYTISSUE.get())).displayItems((parameters, tabData) -> {
				tabData.accept(TheskeptermodModItems.EMPTYTISSUE.get());
				tabData.accept(TheskeptermodModItems.TISSUEBOX.get());
				tabData.accept(TheskeptermodModItems.TISSUE.get());
				tabData.accept(TheskeptermodModItems.HAMBLEPEPPER.get());
				tabData.accept(TheskeptermodModItems.BLUESFLESH.get());
				tabData.accept(TheskeptermodModItems.OVERPOWERDISK.get());
				tabData.accept(TheskeptermodModItems.RAWLATIC.get());
				tabData.accept(TheskeptermodModItems.COOKEDLATIC.get());
				tabData.accept(TheskeptermodModItems.BLUE_3_LEGGINGS.get());
				tabData.accept(TheskeptermodModBlocks.PURPOISE.get().asItem());
				tabData.accept(TheskeptermodModBlocks.PORPOISEDIRT.get().asItem());
				tabData.accept(TheskeptermodModBlocks.COMBBLOCK.get().asItem());
				tabData.accept(TheskeptermodModItems.GLUB_BUCKET.get());
				tabData.accept(TheskeptermodModItems.PURPO.get());
				tabData.accept(TheskeptermodModBlocks.LUCIDPLANT.get().asItem());
				tabData.accept(TheskeptermodModItems.THE_LUCIDSWORD.get());
				tabData.accept(TheskeptermodModBlocks.GEMBLOCK.get().asItem());
				tabData.accept(TheskeptermodModItems.MYSTIC_GEM.get());
				tabData.accept(TheskeptermodModBlocks.DEADLIGHT.get().asItem());
				tabData.accept(TheskeptermodModItems.CUP.get());
			})

					.build());

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.BUILDING_BLOCKS) {

			tabData.accept(TheskeptermodModBlocks.SEPTUS_ORE.get().asItem());
			tabData.accept(TheskeptermodModBlocks.SEPTUS_BLOCK.get().asItem());
			tabData.accept(TheskeptermodModBlocks.H_IOSIS_ORE.get().asItem());
			tabData.accept(TheskeptermodModBlocks.H_IOSIS_BLOCK.get().asItem());
			tabData.accept(TheskeptermodModBlocks.HANDLITE_ORE.get().asItem());
			tabData.accept(TheskeptermodModBlocks.HANDLITE_BLOCK.get().asItem());
			tabData.accept(TheskeptermodModBlocks.PURPLEITE_ORE.get().asItem());
			tabData.accept(TheskeptermodModBlocks.IGNOSA_ORE.get().asItem());
			tabData.accept(TheskeptermodModBlocks.IGNOSA_BLOCK.get().asItem());
			tabData.accept(TheskeptermodModBlocks.GRACKS.get().asItem());
			tabData.accept(TheskeptermodModBlocks.BREAKSTONE_ORE.get().asItem());
			tabData.accept(TheskeptermodModBlocks.BREAKSTONE_BLOCK.get().asItem());
			tabData.accept(TheskeptermodModBlocks.STROCKWOOD_WOOD.get().asItem());
			tabData.accept(TheskeptermodModBlocks.STROCKWOOD_LOG.get().asItem());
			tabData.accept(TheskeptermodModBlocks.STROCKWOOD_PLANKS.get().asItem());
			tabData.accept(TheskeptermodModBlocks.STROCKWOOD_STAIRS.get().asItem());
			tabData.accept(TheskeptermodModBlocks.STROCKWOOD_SLAB.get().asItem());
			tabData.accept(TheskeptermodModBlocks.STROCKWOOD_BUTTON.get().asItem());
			tabData.accept(TheskeptermodModBlocks.BINSTON_WOOD.get().asItem());
			tabData.accept(TheskeptermodModBlocks.BINSTON_LOG.get().asItem());
			tabData.accept(TheskeptermodModBlocks.BINSTON_PLANKS.get().asItem());
			tabData.accept(TheskeptermodModBlocks.BINSTON_STAIRS.get().asItem());
			tabData.accept(TheskeptermodModBlocks.BINSTON_SLAB.get().asItem());
			tabData.accept(TheskeptermodModBlocks.BINSTON_BUTTON.get().asItem());
			tabData.accept(TheskeptermodModBlocks.GLAIN_GEM_ORE.get().asItem());
			tabData.accept(TheskeptermodModBlocks.GLAIN_GEM_BLOCK.get().asItem());
			tabData.accept(TheskeptermodModBlocks.TISSUE_ORE.get().asItem());
			tabData.accept(TheskeptermodModBlocks.TISSUE_BLOCK.get().asItem());
			tabData.accept(TheskeptermodModBlocks.HARK_WOOD.get().asItem());
			tabData.accept(TheskeptermodModBlocks.HARK_LOG.get().asItem());
			tabData.accept(TheskeptermodModBlocks.HARK_PLANKS.get().asItem());
			tabData.accept(TheskeptermodModBlocks.HARK_STAIRS.get().asItem());
			tabData.accept(TheskeptermodModBlocks.HARK_SLAB.get().asItem());
			tabData.accept(TheskeptermodModBlocks.HARK_FENCE.get().asItem());
			tabData.accept(TheskeptermodModBlocks.HARK_FENCE_GATE.get().asItem());
			tabData.accept(TheskeptermodModBlocks.HARK_PRESSURE_PLATE.get().asItem());
			tabData.accept(TheskeptermodModBlocks.HARK_BUTTON.get().asItem());
			tabData.accept(TheskeptermodModBlocks.LUCID_WOOD.get().asItem());
			tabData.accept(TheskeptermodModBlocks.LUCID_LOG.get().asItem());
			tabData.accept(TheskeptermodModBlocks.LUCID_PLANKS.get().asItem());
			tabData.accept(TheskeptermodModBlocks.LUCID_STAIRS.get().asItem());
			tabData.accept(TheskeptermodModBlocks.LUCID_SLAB.get().asItem());
			tabData.accept(TheskeptermodModBlocks.LUCID_FENCE.get().asItem());
			tabData.accept(TheskeptermodModBlocks.LUCID_FENCE_GATE.get().asItem());
			tabData.accept(TheskeptermodModBlocks.LUCID_PRESSURE_PLATE.get().asItem());
			tabData.accept(TheskeptermodModBlocks.LUCID_BUTTON.get().asItem());
			tabData.accept(TheskeptermodModBlocks.FLOZ_WOOD.get().asItem());
			tabData.accept(TheskeptermodModBlocks.FLOZ_LOG.get().asItem());
			tabData.accept(TheskeptermodModBlocks.FLOZ_PLANKS.get().asItem());
			tabData.accept(TheskeptermodModBlocks.FLOZ_STAIRS.get().asItem());
			tabData.accept(TheskeptermodModBlocks.FLOZ_SLAB.get().asItem());
			tabData.accept(TheskeptermodModBlocks.FLOZ_FENCE.get().asItem());
			tabData.accept(TheskeptermodModBlocks.FLOZ_FENCE_GATE.get().asItem());
			tabData.accept(TheskeptermodModBlocks.FLOZ_PRESSURE_PLATE.get().asItem());
			tabData.accept(TheskeptermodModBlocks.FLOZ_BUTTON.get().asItem());
			tabData.accept(TheskeptermodModBlocks.DEEPSHADE_OAK_WOOD.get().asItem());
			tabData.accept(TheskeptermodModBlocks.DEEPSHADE_OAK_LOG.get().asItem());
			tabData.accept(TheskeptermodModBlocks.DEEPSHADE_OAK_PLANKS.get().asItem());
			tabData.accept(TheskeptermodModBlocks.DEEPSHADE_OAK_STAIRS.get().asItem());
			tabData.accept(TheskeptermodModBlocks.DEEPSHADE_OAK_SLAB.get().asItem());
			tabData.accept(TheskeptermodModBlocks.DEEPSHADE_OAK_FENCE.get().asItem());
			tabData.accept(TheskeptermodModBlocks.DEEPSHADE_OAK_FENCE_GATE.get().asItem());
			tabData.accept(TheskeptermodModBlocks.DEEPSHADE_OAK_PRESSURE_PLATE.get().asItem());
			tabData.accept(TheskeptermodModBlocks.DEEPSHADE_OAK_BUTTON.get().asItem());

		} else if (tabData.getTabKey() == CreativeModeTabs.REDSTONE_BLOCKS) {

			tabData.accept(TheskeptermodModBlocks.STROCKWOOD_FENCE_GATE.get().asItem());
			tabData.accept(TheskeptermodModBlocks.STROCKWOOD_PRESSURE_PLATE.get().asItem());
			tabData.accept(TheskeptermodModBlocks.BINSTON_FENCE_GATE.get().asItem());
			tabData.accept(TheskeptermodModBlocks.BINSTON_PRESSURE_PLATE.get().asItem());

		} else if (tabData.getTabKey() == CreativeModeTabs.COMBAT) {

			tabData.accept(TheskeptermodModItems.SEPTUS_SKEPTER.get());
			tabData.accept(TheskeptermodModItems.HIOSIS_SKEPTER.get());
			tabData.accept(TheskeptermodModItems.PURPLET_ARMOR_HELMET.get());
			tabData.accept(TheskeptermodModItems.PURPLET_ARMOR_CHESTPLATE.get());
			tabData.accept(TheskeptermodModItems.PURPLET_ARMOR_LEGGINGS.get());
			tabData.accept(TheskeptermodModItems.PURPLET_ARMOR_BOOTS.get());
			tabData.accept(TheskeptermodModItems.IGNOSA_SKEPTOR.get());
			tabData.accept(TheskeptermodModItems.BREAKSTONE_SWORD.get());
			tabData.accept(TheskeptermodModItems.BREAKSTONE_ARMOR_HELMET.get());
			tabData.accept(TheskeptermodModItems.BREAKSTONE_ARMOR_CHESTPLATE.get());
			tabData.accept(TheskeptermodModItems.BREAKSTONE_ARMOR_LEGGINGS.get());
			tabData.accept(TheskeptermodModItems.BREAKSTONE_ARMOR_BOOTS.get());
			tabData.accept(TheskeptermodModItems.SKUTTLE_ARMOR_HELMET.get());
			tabData.accept(TheskeptermodModItems.SKUTTLE_ARMOR_CHESTPLATE.get());
			tabData.accept(TheskeptermodModItems.SKUTTLE_ARMOR_LEGGINGS.get());
			tabData.accept(TheskeptermodModItems.SKUTTLE_ARMOR_BOOTS.get());
			tabData.accept(TheskeptermodModItems.GLAIN_GEM_SWORD.get());
			tabData.accept(TheskeptermodModItems.GLAIN_GEM_ARMOR_HELMET.get());
			tabData.accept(TheskeptermodModItems.GLAIN_GEM_ARMOR_CHESTPLATE.get());
			tabData.accept(TheskeptermodModItems.GLAIN_GEM_ARMOR_LEGGINGS.get());
			tabData.accept(TheskeptermodModItems.GLAIN_GEM_ARMOR_BOOTS.get());
			tabData.accept(TheskeptermodModItems.THROWING_BRICK.get());
			tabData.accept(TheskeptermodModItems.TISSUEBOXED_SWORD.get());
			tabData.accept(TheskeptermodModItems.LUCIDMANSCLOTHES_HELMET.get());
			tabData.accept(TheskeptermodModItems.LUCIDMANSCLOTHES_LEGGINGS.get());
			tabData.accept(TheskeptermodModItems.LUCIDMANSCLOTHES_BOOTS.get());

		} else if (tabData.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {

			tabData.accept(TheskeptermodModItems.SKEPTER_SHARD.get());
			tabData.accept(TheskeptermodModItems.SEPTUS.get());
			tabData.accept(TheskeptermodModItems.H_IOSIS.get());
			tabData.accept(TheskeptermodModItems.HANDLITE_INGOT.get());
			tabData.accept(TheskeptermodModItems.PURPLEITE.get());
			tabData.accept(TheskeptermodModItems.IGNOSA_INGOT.get());
			tabData.accept(TheskeptermodModItems.DISO_INGOT.get());
			tabData.accept(TheskeptermodModItems.WASTER_BUCKET.get());
			tabData.accept(TheskeptermodModItems.BREAKSTONE_INGOT.get());
			tabData.accept(TheskeptermodModItems.ENOSIS_DUST.get());
			tabData.accept(TheskeptermodModItems.SKUTTLER_SPAWN_EGG.get());
			tabData.accept(TheskeptermodModItems.SKUTTLE_GEM.get());
			tabData.accept(TheskeptermodModItems.CLATTLE_SPAWN_EGG.get());
			tabData.accept(TheskeptermodModItems.SKEPTICAL_PIG_SPAWN_EGG.get());
			tabData.accept(TheskeptermodModItems.BRICK_BUT_DIFFERENT.get());
			tabData.accept(TheskeptermodModItems.GLAIN_GEM.get());
			tabData.accept(TheskeptermodModItems.BASICLYBLUE_SPAWN_EGG.get());
			tabData.accept(TheskeptermodModItems.LANE_SPAWN_EGG.get());
			tabData.accept(TheskeptermodModItems.DRAFT_SPAWN_EGG.get());
			tabData.accept(TheskeptermodModItems.SCEPTICALBLUE_SPAWN_EGG.get());
			tabData.accept(TheskeptermodModItems.LOST_BUILDER_SPAWN_EGG.get());
			tabData.accept(TheskeptermodModItems.SQUEEMLING_SPAWN_EGG.get());
			tabData.accept(TheskeptermodModItems.GRODGELING_SPAWN_EGG.get());
			tabData.accept(TheskeptermodModItems.GLOW_BEAR_SPAWN_EGG.get());
			tabData.accept(TheskeptermodModItems.CURRUPT_MACE_SPAWN_EGG.get());

		} else if (tabData.getTabKey() == CreativeModeTabs.INGREDIENTS) {

			tabData.accept(TheskeptermodModItems.SKEPTER_HANDLE.get());
			tabData.accept(TheskeptermodModItems.THE_USELESS_DISK.get());
			tabData.accept(TheskeptermodModItems.USELESS_DISK_2_USELESS_BOOGALOO.get());
			tabData.accept(TheskeptermodModItems.USELESS_DISK_3_EVENMOREUSELESS.get());
			tabData.accept(TheskeptermodModItems.DISK_OF_THE_INGOT.get());
			tabData.accept(TheskeptermodModItems.TISSUE_DUST.get());
			tabData.accept(TheskeptermodModItems.NOBODY_BUT_US.get());

		} else if (tabData.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {

			tabData.accept(TheskeptermodModItems.BASIC_SKEPTER.get());
			tabData.accept(TheskeptermodModItems.HAMMER.get());
			tabData.accept(TheskeptermodModItems.SKEPTIC_DIMENSION.get());
			tabData.accept(TheskeptermodModItems.BREAKSTONE_PICKAXE.get());
			tabData.accept(TheskeptermodModItems.BREAKSTONE_AXE.get());
			tabData.accept(TheskeptermodModItems.BREAKSTONE_SHOVEL.get());
			tabData.accept(TheskeptermodModItems.BREAKSTONE_HOE.get());
			tabData.accept(TheskeptermodModItems.BOTTLE_OF_STANGE_LIQUID.get());
			tabData.accept(TheskeptermodModItems.GLAIN_GEM_PICKAXE.get());
			tabData.accept(TheskeptermodModItems.GLAIN_GEM_AXE.get());
			tabData.accept(TheskeptermodModItems.GLAIN_GEM_SHOVEL.get());
			tabData.accept(TheskeptermodModItems.GLAIN_GEM_HOE.get());
			tabData.accept(TheskeptermodModItems.TISSUEBOXED_PICKAXE.get());
			tabData.accept(TheskeptermodModItems.TISSUEBOXED_SHOVEL.get());
			tabData.accept(TheskeptermodModItems.OVERPOWERSKEPTER.get());
			tabData.accept(TheskeptermodModItems.NEW_SKEPTER.get());
			tabData.accept(TheskeptermodModItems.NOLAANDS.get());

		} else if (tabData.getTabKey() == CreativeModeTabs.NATURAL_BLOCKS) {

			tabData.accept(TheskeptermodModBlocks.POCKUS.get().asItem());
			tabData.accept(TheskeptermodModBlocks.PLOSIS.get().asItem());
			tabData.accept(TheskeptermodModBlocks.STROCKWOOD_LEAVES.get().asItem());
			tabData.accept(TheskeptermodModBlocks.STROCKWOOD_FENCE.get().asItem());
			tabData.accept(TheskeptermodModBlocks.BLOOMSIS.get().asItem());
			tabData.accept(TheskeptermodModBlocks.BINSTON_LEAVES.get().asItem());
			tabData.accept(TheskeptermodModBlocks.BINSTON_FENCE.get().asItem());
			tabData.accept(TheskeptermodModBlocks.HARK_LEAVES.get().asItem());
			tabData.accept(TheskeptermodModBlocks.LUCID_LEAVES.get().asItem());
			tabData.accept(TheskeptermodModBlocks.FLOZ_LEAVES.get().asItem());
			tabData.accept(TheskeptermodModBlocks.NO_FRUITSEED.get().asItem());
			tabData.accept(TheskeptermodModBlocks.DEEPSHADE_OAK_LEAVES.get().asItem());
			tabData.accept(TheskeptermodModBlocks.DEEP_BLOOM.get().asItem());

		} else if (tabData.getTabKey() == CreativeModeTabs.FOOD_AND_DRINKS) {

			tabData.accept(TheskeptermodModItems.SKUTTLEFLESH.get());
			tabData.accept(TheskeptermodModItems.NO_FRUIT.get());

		}
	}
}

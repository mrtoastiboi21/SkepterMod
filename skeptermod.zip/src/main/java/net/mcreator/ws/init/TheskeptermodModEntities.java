
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.ws.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.event.entity.RegisterSpawnPlacementsEvent;
import net.neoforged.neoforge.event.entity.EntityAttributeCreationEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;
import net.minecraft.core.registries.Registries;

import net.mcreator.ws.entity.ThrowingBrickProjectileEntity;
import net.mcreator.ws.entity.SqueemlingEntity;
import net.mcreator.ws.entity.SkuttlerEntity;
import net.mcreator.ws.entity.SkepticalPigEntity;
import net.mcreator.ws.entity.ScepticalblueEntity;
import net.mcreator.ws.entity.LostBuilderEntity;
import net.mcreator.ws.entity.LaneEntity;
import net.mcreator.ws.entity.GrodgelingEntity;
import net.mcreator.ws.entity.GlowBearEntity;
import net.mcreator.ws.entity.DraftEntity;
import net.mcreator.ws.entity.CurruptMaceEntity;
import net.mcreator.ws.entity.ClattleEntity;
import net.mcreator.ws.entity.BasiclyblueEntity;
import net.mcreator.ws.TheskeptermodMod;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD)
public class TheskeptermodModEntities {
	public static final DeferredRegister<EntityType<?>> REGISTRY = DeferredRegister.create(Registries.ENTITY_TYPE, TheskeptermodMod.MODID);
	public static final DeferredHolder<EntityType<?>, EntityType<SkuttlerEntity>> SKUTTLER = register("skuttler",
			EntityType.Builder.<SkuttlerEntity>of(SkuttlerEntity::new, MobCategory.CREATURE).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).fireImmune().sized(0.9f, 0.9f));
	public static final DeferredHolder<EntityType<?>, EntityType<ClattleEntity>> CLATTLE = register("clattle",
			EntityType.Builder.<ClattleEntity>of(ClattleEntity::new, MobCategory.CREATURE).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).fireImmune().sized(0.9f, 1.4f));
	public static final DeferredHolder<EntityType<?>, EntityType<SkepticalPigEntity>> SKEPTICAL_PIG = register("skeptical_pig",
			EntityType.Builder.<SkepticalPigEntity>of(SkepticalPigEntity::new, MobCategory.CREATURE).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3)

					.sized(0.9f, 0.9f));
	public static final DeferredHolder<EntityType<?>, EntityType<ThrowingBrickProjectileEntity>> THROWING_BRICK_PROJECTILE = register("throwing_brick_projectile",
			EntityType.Builder.<ThrowingBrickProjectileEntity>of(ThrowingBrickProjectileEntity::new, MobCategory.MISC).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final DeferredHolder<EntityType<?>, EntityType<BasiclyblueEntity>> BASICLYBLUE = register("basiclyblue",
			EntityType.Builder.<BasiclyblueEntity>of(BasiclyblueEntity::new, MobCategory.CREATURE).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).fireImmune().sized(0.6f, 1.8f));
	public static final DeferredHolder<EntityType<?>, EntityType<LaneEntity>> LANE = register("lane",
			EntityType.Builder.<LaneEntity>of(LaneEntity::new, MobCategory.CREATURE).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).fireImmune().sized(0.6f, 0.7f));
	public static final DeferredHolder<EntityType<?>, EntityType<DraftEntity>> DRAFT = register("draft",
			EntityType.Builder.<DraftEntity>of(DraftEntity::new, MobCategory.CREATURE).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).fireImmune().sized(0.6f, 1.8f));
	public static final DeferredHolder<EntityType<?>, EntityType<ScepticalblueEntity>> SCEPTICALBLUE = register("scepticalblue",
			EntityType.Builder.<ScepticalblueEntity>of(ScepticalblueEntity::new, MobCategory.CREATURE).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).fireImmune().sized(0.6f, 1.8f));
	public static final DeferredHolder<EntityType<?>, EntityType<LostBuilderEntity>> LOST_BUILDER = register("lost_builder",
			EntityType.Builder.<LostBuilderEntity>of(LostBuilderEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).fireImmune().sized(0.6f, 1.8f));
	public static final DeferredHolder<EntityType<?>, EntityType<SqueemlingEntity>> SQUEEMLING = register("squeemling",
			EntityType.Builder.<SqueemlingEntity>of(SqueemlingEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3)

					.sized(0.6f, 1.8f));
	public static final DeferredHolder<EntityType<?>, EntityType<GrodgelingEntity>> GRODGELING = register("grodgeling",
			EntityType.Builder.<GrodgelingEntity>of(GrodgelingEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3)

					.sized(0.6f, 1.8f));
	public static final DeferredHolder<EntityType<?>, EntityType<GlowBearEntity>> GLOW_BEAR = register("glow_bear",
			EntityType.Builder.<GlowBearEntity>of(GlowBearEntity::new, MobCategory.MISC).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3)

					.sized(0.6f, 1.8f));
	public static final DeferredHolder<EntityType<?>, EntityType<CurruptMaceEntity>> CURRUPT_MACE = register("currupt_mace",
			EntityType.Builder.<CurruptMaceEntity>of(CurruptMaceEntity::new, MobCategory.MISC).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3)

					.sized(0.8f, 4.6f));

	// Start of user code block custom entities
	// End of user code block custom entities
	private static <T extends Entity> DeferredHolder<EntityType<?>, EntityType<T>> register(String registryname, EntityType.Builder<T> entityTypeBuilder) {
		return REGISTRY.register(registryname, () -> (EntityType<T>) entityTypeBuilder.build(registryname));
	}

	@SubscribeEvent
	public static void init(RegisterSpawnPlacementsEvent event) {
		SkuttlerEntity.init(event);
		ClattleEntity.init(event);
		SkepticalPigEntity.init(event);
		BasiclyblueEntity.init(event);
		LaneEntity.init(event);
		DraftEntity.init(event);
		ScepticalblueEntity.init(event);
		LostBuilderEntity.init(event);
		SqueemlingEntity.init(event);
		GrodgelingEntity.init(event);
		GlowBearEntity.init(event);
		CurruptMaceEntity.init(event);
	}

	@SubscribeEvent
	public static void registerAttributes(EntityAttributeCreationEvent event) {
		event.put(SKUTTLER.get(), SkuttlerEntity.createAttributes().build());
		event.put(CLATTLE.get(), ClattleEntity.createAttributes().build());
		event.put(SKEPTICAL_PIG.get(), SkepticalPigEntity.createAttributes().build());
		event.put(BASICLYBLUE.get(), BasiclyblueEntity.createAttributes().build());
		event.put(LANE.get(), LaneEntity.createAttributes().build());
		event.put(DRAFT.get(), DraftEntity.createAttributes().build());
		event.put(SCEPTICALBLUE.get(), ScepticalblueEntity.createAttributes().build());
		event.put(LOST_BUILDER.get(), LostBuilderEntity.createAttributes().build());
		event.put(SQUEEMLING.get(), SqueemlingEntity.createAttributes().build());
		event.put(GRODGELING.get(), GrodgelingEntity.createAttributes().build());
		event.put(GLOW_BEAR.get(), GlowBearEntity.createAttributes().build());
		event.put(CURRUPT_MACE.get(), CurruptMaceEntity.createAttributes().build());
	}
}

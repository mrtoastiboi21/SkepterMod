
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.ws.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.Registries;

import net.mcreator.ws.TheskeptermodMod;

public class TheskeptermodModSounds {
	public static final DeferredRegister<SoundEvent> REGISTRY = DeferredRegister.create(Registries.SOUND_EVENT, TheskeptermodMod.MODID);
	public static final DeferredHolder<SoundEvent, SoundEvent> BERRYSPECIESHURT = REGISTRY.register("berryspecieshurt", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("theskeptermod", "berryspecieshurt")));
	public static final DeferredHolder<SoundEvent, SoundEvent> BERRYSPECIESDEATH = REGISTRY.register("berryspeciesdeath", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("theskeptermod", "berryspeciesdeath")));
	public static final DeferredHolder<SoundEvent, SoundEvent> PLACEHOLDERSONG = REGISTRY.register("placeholdersong", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("theskeptermod", "placeholdersong")));
}

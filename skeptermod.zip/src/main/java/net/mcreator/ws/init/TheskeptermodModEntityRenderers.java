
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.ws.init;

import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.minecraft.client.renderer.entity.ThrownItemRenderer;

import net.mcreator.ws.client.renderer.SqueemlingRenderer;
import net.mcreator.ws.client.renderer.SkuttlerRenderer;
import net.mcreator.ws.client.renderer.SkepticalPigRenderer;
import net.mcreator.ws.client.renderer.ScepticalblueRenderer;
import net.mcreator.ws.client.renderer.LostBuilderRenderer;
import net.mcreator.ws.client.renderer.LaneRenderer;
import net.mcreator.ws.client.renderer.GrodgelingRenderer;
import net.mcreator.ws.client.renderer.GlowBearRenderer;
import net.mcreator.ws.client.renderer.DraftRenderer;
import net.mcreator.ws.client.renderer.CurruptMaceRenderer;
import net.mcreator.ws.client.renderer.ClattleRenderer;
import net.mcreator.ws.client.renderer.BasiclyblueRenderer;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class TheskeptermodModEntityRenderers {
	@SubscribeEvent
	public static void registerEntityRenderers(EntityRenderersEvent.RegisterRenderers event) {
		event.registerEntityRenderer(TheskeptermodModEntities.SKUTTLER.get(), SkuttlerRenderer::new);
		event.registerEntityRenderer(TheskeptermodModEntities.CLATTLE.get(), ClattleRenderer::new);
		event.registerEntityRenderer(TheskeptermodModEntities.SKEPTICAL_PIG.get(), SkepticalPigRenderer::new);
		event.registerEntityRenderer(TheskeptermodModEntities.THROWING_BRICK_PROJECTILE.get(), ThrownItemRenderer::new);
		event.registerEntityRenderer(TheskeptermodModEntities.BASICLYBLUE.get(), BasiclyblueRenderer::new);
		event.registerEntityRenderer(TheskeptermodModEntities.LANE.get(), LaneRenderer::new);
		event.registerEntityRenderer(TheskeptermodModEntities.DRAFT.get(), DraftRenderer::new);
		event.registerEntityRenderer(TheskeptermodModEntities.SCEPTICALBLUE.get(), ScepticalblueRenderer::new);
		event.registerEntityRenderer(TheskeptermodModEntities.LOST_BUILDER.get(), LostBuilderRenderer::new);
		event.registerEntityRenderer(TheskeptermodModEntities.SQUEEMLING.get(), SqueemlingRenderer::new);
		event.registerEntityRenderer(TheskeptermodModEntities.GRODGELING.get(), GrodgelingRenderer::new);
		event.registerEntityRenderer(TheskeptermodModEntities.GLOW_BEAR.get(), GlowBearRenderer::new);
		event.registerEntityRenderer(TheskeptermodModEntities.CURRUPT_MACE.get(), CurruptMaceRenderer::new);
	}
}


/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.ws.init;

import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.mcreator.ws.client.model.Modelsqueemling;
import net.mcreator.ws.client.model.Modelcurruptmacev2;
import net.mcreator.ws.client.model.ModelGlowingBoi;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD, value = {Dist.CLIENT})
public class TheskeptermodModModels {
	@SubscribeEvent
	public static void registerLayerDefinitions(EntityRenderersEvent.RegisterLayerDefinitions event) {
		event.registerLayerDefinition(Modelcurruptmacev2.LAYER_LOCATION, Modelcurruptmacev2::createBodyLayer);
		event.registerLayerDefinition(ModelGlowingBoi.LAYER_LOCATION, ModelGlowingBoi::createBodyLayer);
		event.registerLayerDefinition(Modelsqueemling.LAYER_LOCATION, Modelsqueemling::createBodyLayer);
	}
}
